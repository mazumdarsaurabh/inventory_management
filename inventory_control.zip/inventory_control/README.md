This is a inventory management tool Demo version
